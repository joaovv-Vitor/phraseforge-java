Crie um protótipo de alta fidelidade para uma aplicação web chamada **PhraseForge**, uma plataforma minimalista para descoberta, organização e gerenciamento de frases de pensadores, filósofos, escritores e outras personalidades.

## Conceito visual

A interface deve ser extremamente minimalista, elegante e editorial, inspirada em páginas de livros, cartões de citações e interfaces de leitura.

Use como referência visual a imagem fornecida: uma composição muito limpa, com fundo quase branco, bastante espaço negativo, tipografia discreta e a frase posicionada como elemento principal.

Não copie literalmente o layout da referência. Use apenas a linguagem visual como inspiração.

A sensação geral deve ser:

* minimalista
* sofisticada
* calma
* editorial
* intelectual
* contemporânea
* muito espaço negativo
* poucos elementos na tela
* foco absoluto no conteúdo

Evite aparência de dashboard administrativo tradicional.

## Identidade visual

Use uma paleta extremamente neutra:

* fundo principal: branco ou off-white
* texto principal: preto ou cinza muito escuro
* texto secundário: cinza médio
* bordas: cinza muito claro
* elementos de destaque: preto
* pequenos detalhes podem utilizar um tom cinza quente

Não utilizar gradientes, sombras fortes, cards excessivamente arredondados ou cores vibrantes.

A interface deve parecer uma mistura de:

* livro
* revista editorial
* biblioteca digital
* aplicativo de leitura

## Tipografia

Use uma combinação tipográfica elegante.

Para as frases, prefira uma fonte serifada ou uma serif moderna, transmitindo sensação literária.

Para navegação, botões, filtros e informações secundárias, utilize uma fonte sans-serif simples.

A frase deve possuir tamanho relativamente grande e bastante espaçamento entre linhas.

Exemplo visual:

"A simplicidade é o último grau de sofisticação."

— Leonardo da Vinci

A frase deve ser o maior elemento visual da tela.

---

# Tela principal — Quote of the Day

Criar uma página inicial extremamente limpa.

No topo:

PhraseForge

À direita:

* Explore
* Authors
* Categories
* Search
* botão discreto de Favorites

O header deve ser pequeno e discreto.

No centro da página, apresentar uma única frase.

Estrutura:

[ categoria ]

"Uma frase longa deve ocupar
algumas linhas, mantendo
uma composição equilibrada."

— Autor da frase
Ano

Abaixo da frase, mostrar pequenas ações:

♡ Favorite
↗ Share
Copy

Na parte inferior da composição, um botão minimalista:

New Quote

O botão deve ser discreto, com borda fina e formato arredondado.

A página deve ter bastante espaço vazio ao redor da frase.

---

# Tela Explore

Criar uma página para explorar todas as frases.

Manter o mesmo header minimalista.

No topo da página:

Explore

Subtítulo:

Discover ideas, thoughts and words from different thinkers.

Abaixo, uma barra de pesquisa minimalista:

Search phrases, authors or topics...

Adicionar filtros discretos:

All
Philosophy
Literature
Science
Motivation
Life
Knowledge

Abaixo, mostrar uma grade de frases.

Cada item da grade deve parecer mais um pequeno cartão editorial do que um card de dashboard.

Exemplo:

"Conhece-te a ti mesmo."

— Sócrates

Philosophy · Ancient Greece

Os cards devem ter:

* fundo neutro
* borda extremamente sutil
* bastante padding
* tipografia elegante
* nenhum excesso de informação

---

# Tela de detalhes da frase

Criar uma página focada completamente em uma frase.

No centro:

"Não é o que acontece com você,
mas como você reage que importa."

— Epicteto

Abaixo:

Philosophy
Stoicism
Ancient Philosophy

Year: approximately 100 AD

Ações:

Favorite
Copy Quote
Share

Na parte inferior:

More from Epictetus

Mostrar algumas frases relacionadas do mesmo autor.

---

# Tela Authors

Criar uma biblioteca de autores.

Título:

Authors

Subtítulo:

Explore the thinkers behind the words.

Adicionar busca:

Search authors...

Mostrar autores de forma extremamente simples, em uma lista ou grid editorial.

Exemplo:

Socrates
Ancient Greek philosopher

Marcus Aurelius
Roman emperor and Stoic philosopher

Friedrich Nietzsche
German philosopher

Doris Janzen Longacre
Writer

Cada autor deve ser apresentado de forma discreta, sem grandes imagens ou elementos decorativos.

---

# Tela do autor

Ao abrir um autor:

Marcus Aurelius

Roman emperor and Stoic philosopher

133 phrases

Uma pequena descrição biográfica.

Depois:

Quotes by Marcus Aurelius

Mostrar as frases do autor em uma lista editorial.

---

# Tela Categories

Criar uma página para explorar categorias.

Título:

Categories

Mostrar categorias como uma lista elegante:

Philosophy
Literature
Science
Life
Love
Knowledge
Motivation
Existentialism
Stoicism
Wisdom

Ao passar o mouse sobre uma categoria, criar uma interação visual extremamente sutil.

---

# Tela Favorites

Criar uma página para usuários visualizarem suas frases favoritas.

Título:

Favorites

Mostrar uma lista de frases favoritas.

Cada frase deve apresentar:

conteúdo
autor
categoria
ação de remover dos favoritos

Manter o mesmo estilo editorial e minimalista.

---

# Tela de busca

Criar uma experiência de busca limpa.

Ao clicar em Search no header, abrir uma página dedicada.

No centro:

Search PhraseForge

Campo de pesquisa grande:

Search for a phrase, author or topic...

Abaixo mostrar resultados conforme a pesquisa.

Permitir encontrar frases por:

* conteúdo
* autor
* categoria
* tag

Os resultados devem manter o estilo visual da página Explore.

---

# Área administrativa

Criar também uma área administrativa simples para gerenciamento do conteúdo.

IMPORTANTE:

A área administrativa pode ser um pouco mais funcional e menos editorial, mas ainda deve manter a identidade visual do PhraseForge.

Criar:

Dashboard
Phrases
Authors
Categories
Tags

Na tela de gerenciamento de frases:

* tabela/lista de frases
* busca
* filtros
* botão Add Phrase
* editar
* excluir

Tela Add Phrase:

Content
Author
Year
Language
Categories
Tags

Botão:

Save Phrase

---

# Responsividade

O protótipo deve ser responsivo.

Criar versões para:

* desktop
* tablet
* mobile

No mobile:

* substituir o menu horizontal por menu compacto
* manter a frase como elemento principal
* reduzir tamanhos tipográficos proporcionalmente
* preservar bastante espaço negativo
* evitar que a interface pareça uma versão comprimida do desktop

---

# Microinterações

Utilizar microinterações muito discretas.

Exemplos:

* hover suave em links
* animação pequena ao favoritar
* feedback visual ao copiar uma frase
* transição suave ao trocar a frase
* fade discreto entre resultados
* botão New Quote com pequena animação

Evitar animações exageradas.

---

# Princípios de design

Priorize:

1. A frase é o protagonista.
2. Muito espaço negativo.
3. Tipografia elegante.
4. Poucos elementos na tela.
5. Navegação simples.
6. Hierarquia visual clara.
7. Aparência editorial.
8. Consistência entre todas as telas.
9. A interface deve parecer intencionalmente simples.
10. Evitar elementos que pareçam genéricos de templates SaaS.

O resultado final deve parecer um produto real e refinado, não apenas um CRUD gerado automaticamente.

O PhraseForge deve transmitir a sensação de abrir um livro e encontrar uma frase interessante, mas com a conveniência de uma biblioteca digital moderna.

Crie componentes reutilizáveis para:

* Header
* QuoteCard
* QuoteDisplay
* AuthorItem
* CategoryItem
* Tag
* SearchBar
* Filter
* Button
* FavoriteButton
* ShareButton
* Pagination
* Modal

Utilize dados fictícios realistas de filósofos, escritores e pensadores para preencher o protótipo.
