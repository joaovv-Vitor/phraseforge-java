interface HeaderProps {
  currentPage: string
  navigate: (page: string, extra?: Record<string, string>) => void
  favCount: number
  mobileMenuOpen: boolean
  setMobileMenuOpen: (v: boolean) => void
}

export default function Header({
  currentPage,
  navigate,
  favCount,
  mobileMenuOpen,
  setMobileMenuOpen,
}: HeaderProps) {
  const navLinks = [
    { label: 'Explore', page: 'explore' },
    { label: 'Authors', page: 'authors' },
    { label: 'Categories', page: 'categories' },
    { label: 'This Week', page: 'weekly' },
    { label: 'Search', page: 'search' },
  ]

  return (
    <header
      style={{
        borderBottom: '1px solid var(--border-subtle)',
        background: 'var(--bg)',
        position: 'sticky',
        top: 0,
        zIndex: 100,
      }}
    >
      <div
        style={{
          maxWidth: '1040px',
          margin: '0 auto',
          padding: '0 2rem',
          height: '52px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}
      >
        {/* Logo */}
        <button
          onClick={() => navigate('home')}
          style={{
            background: 'none',
            border: 'none',
            fontFamily: 'Lora, serif',
            fontSize: '1rem',
            fontWeight: 500,
            color: 'var(--text)',
            letterSpacing: '-0.01em',
            padding: 0,
          }}
        >
          PhraseForge
        </button>

        {/* Desktop nav */}
        <nav
          style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}
          className="desktop-nav"
        >
          {navLinks.map(({ label, page }) => (
            <button
              key={page}
              onClick={() => navigate(page)}
              style={{
                background: 'none',
                border: 'none',
                fontSize: '0.8125rem',
                fontWeight: currentPage === page ? 500 : 400,
                color: currentPage === page ? 'var(--text)' : 'var(--text-secondary)',
                padding: '6px 12px',
                borderRadius: 'var(--radius)',
                transition: 'color 0.15s',
              }}
              onMouseEnter={(e) => {
                if (currentPage !== page)
                  (e.target as HTMLElement).style.color = 'var(--text)'
              }}
              onMouseLeave={(e) => {
                if (currentPage !== page)
                  (e.target as HTMLElement).style.color = 'var(--text-secondary)'
              }}
            >
              {label}
            </button>
          ))}
          <button
            onClick={() => navigate('favorites')}
            style={{
              background: 'none',
              border: '1px solid var(--border)',
              fontSize: '0.8125rem',
              fontWeight: currentPage === 'favorites' ? 500 : 400,
              color: currentPage === 'favorites' ? 'var(--text)' : 'var(--text-secondary)',
              padding: '5px 12px',
              borderRadius: '99px',
              marginLeft: '4px',
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              transition: 'all 0.15s',
            }}
          >
            <span style={{ fontSize: '0.75rem' }}>♡</span>
          </button>
        </nav>

        {/* Mobile hamburger */}
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          style={{
            display: 'none',
            background: 'none',
            border: 'none',
            padding: '4px',
            color: 'var(--text)',
          }}
          className="mobile-menu-btn"
        >
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
            {mobileMenuOpen ? (
              <>
                <line x1="3" y1="3" x2="15" y2="15" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                <line x1="15" y1="3" x2="3" y2="15" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
              </>
            ) : (
              <>
                <line x1="3" y1="5" x2="15" y2="5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                <line x1="3" y1="9" x2="15" y2="9" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                <line x1="3" y1="13" x2="15" y2="13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
              </>
            )}
          </svg>
        </button>
      </div>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div
          style={{
            borderTop: '1px solid var(--border-subtle)',
            padding: '1rem 2rem',
            display: 'flex',
            flexDirection: 'column',
            gap: '0.25rem',
          }}
          className="mobile-menu"
        >
          {[...navLinks, { label: 'Favorites', page: 'favorites' }].map(({ label, page }) => (
            <button
              key={page}
              onClick={() => { navigate(page); setMobileMenuOpen(false) }}
              style={{
                background: 'none',
                border: 'none',
                fontSize: '0.9375rem',
                fontWeight: currentPage === page ? 500 : 400,
                color: currentPage === page ? 'var(--text)' : 'var(--text-secondary)',
                padding: '10px 0',
                textAlign: 'left',
                borderBottom: '1px solid var(--border-subtle)',
              }}
            >
              {label}
            </button>
          ))}
        </div>
      )}

      <style>{`
        @media (max-width: 640px) {
          .desktop-nav { display: none !important; }
          .mobile-menu-btn { display: flex !important; }
        }
      `}</style>
    </header>
  )
}
