import { useState } from 'react'
import Header from './components/Header'
import Home from './pages/Home'
import Explore from './pages/Explore'
import QuoteDetail from './pages/QuoteDetail'
import Authors from './pages/Authors'
import AuthorDetail from './pages/AuthorDetail'
import Categories from './pages/Categories'
import Favorites from './pages/Favorites'
import Search from './pages/Search'
import Admin from './pages/Admin'
import Weekly from './pages/Weekly'

type PageState =
  | { page: 'home' }
  | { page: 'explore' }
  | { page: 'quote'; id: string }
  | { page: 'authors' }
  | { page: 'author'; id: string }
  | { page: 'categories' }
  | { page: 'favorites' }
  | { page: 'search' }
  | { page: 'weekly' }
  | { page: 'admin' }

export default function App() {
  const [view, setView] = useState<PageState>({ page: 'home' })
  const [favorites, setFavorites] = useState<string[]>([])
  const [copied, setCopied] = useState<string | null>(null)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const navigate = (page: string, extra?: Record<string, string>) => {
    setMobileMenuOpen(false)
    if (page === 'quote' && extra?.id) setView({ page: 'quote', id: extra.id })
    else if (page === 'author' && extra?.id) setView({ page: 'author', id: extra.id })
    else setView({ page: page as PageState['page'] })
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const toggleFavorite = (id: string) => {
    setFavorites((prev) =>
      prev.includes(id) ? prev.filter((f) => f !== id) : [...prev, id],
    )
  }

  const commonProps = { favorites, toggleFavorite, navigate, copied, setCopied }

  return (
    <div style={{ background: 'var(--bg)', minHeight: '100vh' }}>
      {view.page !== 'admin' && (
        <Header
          currentPage={view.page}
          navigate={navigate}
          favCount={favorites.length}
          mobileMenuOpen={mobileMenuOpen}
          setMobileMenuOpen={setMobileMenuOpen}
        />
      )}

      {view.page === 'home' && <Home {...commonProps} />}
      {view.page === 'explore' && <Explore {...commonProps} />}
      {view.page === 'quote' && <QuoteDetail {...commonProps} quoteId={view.id} />}
      {view.page === 'authors' && <Authors navigate={navigate} />}
      {view.page === 'author' && <AuthorDetail {...commonProps} authorId={view.id} />}
      {view.page === 'categories' && <Categories navigate={navigate} />}
      {view.page === 'favorites' && <Favorites {...commonProps} />}
      {view.page === 'search' && <Search {...commonProps} />}
      {view.page === 'weekly' && <Weekly {...commonProps} />}
      {view.page === 'admin' && (
        <div>
          <div
            style={{
              borderBottom: '1px solid var(--border-subtle)',
              padding: '0 2rem',
              height: '52px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              background: 'var(--bg)',
              position: 'sticky',
              top: 0,
              zIndex: 100,
            }}
          >
            <button
              onClick={() => navigate('home')}
              style={{
                background: 'none',
                border: 'none',
                fontFamily: 'Lora, serif',
                fontSize: '1rem',
                fontWeight: 500,
                color: 'var(--text)',
                letterSpacing: '-0.01em',
                padding: 0,
              }}
            >
              PhraseForge
            </button>
            <span
              style={{
                fontSize: '0.6875rem',
                fontWeight: 600,
                letterSpacing: '0.1em',
                textTransform: 'uppercase',
                color: 'var(--text-tertiary)',
              }}
            >
              Admin
            </span>
            <button
              onClick={() => navigate('home')}
              style={{
                background: 'none',
                border: 'none',
                fontSize: '0.8125rem',
                color: 'var(--text-secondary)',
                padding: 0,
                transition: 'color 0.15s',
              }}
              onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.color = 'var(--text)')}
              onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.color = 'var(--text-secondary)')}
            >
              ← Back to site
            </button>
          </div>
          <Admin />
        </div>
      )}

      {/* Admin access link */}
      {view.page !== 'admin' && (
        <div style={{ textAlign: 'center', padding: '1.5rem', borderTop: '1px solid var(--border-subtle)' }}>
          <button
            onClick={() => navigate('admin')}
            style={{
              background: 'none',
              border: 'none',
              fontSize: '0.75rem',
              color: 'var(--text-tertiary)',
              transition: 'color 0.15s',
            }}
            onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.color = 'var(--text-secondary)')}
            onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.color = 'var(--text-tertiary)')}
          >
            Admin
          </button>
        </div>
      )}
    </div>
  )
}
