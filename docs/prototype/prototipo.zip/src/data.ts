export interface Author {
  id: string
  name: string
  description: string
  bio: string
  era: string
}

export interface Quote {
  id: string
  content: string
  authorId: string
  year: string
  categories: string[]
  tags: string[]
  language: string
}

export const AUTHORS: Author[] = [
  {
    id: 'marcus-aurelius',
    name: 'Marcus Aurelius',
    description: 'Roman emperor and Stoic philosopher',
    era: '121–180 AD',
    bio: 'Marcus Aurelius Antoninus was Roman emperor from 161 to 180 AD and a Stoic philosopher. He is considered one of the most respected emperors in Roman history. His private writings, known as the Meditations, are a significant source of the modern understanding of Stoic philosophy.',
  },
  {
    id: 'epictetus',
    name: 'Epictetus',
    description: 'Greek Stoic philosopher',
    era: 'c. 50–135 AD',
    bio: 'Epictetus was a Greek Stoic philosopher. He was born a slave and taught that philosophy is a way of life and not just a theoretical discipline. His teachings were written down and published by his pupil Arrian in the Discourses and the Enchiridion.',
  },
  {
    id: 'socrates',
    name: 'Socrates',
    description: 'Ancient Greek philosopher',
    era: '470–399 BC',
    bio: 'Socrates was a Greek philosopher from Athens who is credited as the founder of Western philosophy and among the first moral philosophers of the ethical tradition. He is known for the Socratic method of inquiry, which he used to examine ideas and expose contradictions.',
  },
  {
    id: 'nietzsche',
    name: 'Friedrich Nietzsche',
    description: 'German philosopher and cultural critic',
    era: '1844–1900',
    bio: 'Friedrich Wilhelm Nietzsche was a German philosopher, cultural critic, and philologist. His work has exerted a profound influence on modern intellectual history. He challenged the foundations of Christianity and traditional morality, famously declaring the "death of God."',
  },
  {
    id: 'simone-de-beauvoir',
    name: 'Simone de Beauvoir',
    description: 'French existentialist philosopher and writer',
    era: '1908–1986',
    bio: 'Simone de Beauvoir was a French existentialist philosopher, writer, social theorist, and feminist activist. She is known for her treatise The Second Sex, a detailed analysis of women\'s oppression and a foundational tract of contemporary feminism.',
  },
  {
    id: 'virginia-woolf',
    name: 'Virginia Woolf',
    description: 'English writer and modernist',
    era: '1882–1941',
    bio: 'Adeline Virginia Woolf was an English writer, considered one of the most important modernist twentieth-century authors and a pioneer in the use of stream of consciousness as a narrative device.',
  },
  {
    id: 'albert-camus',
    name: 'Albert Camus',
    description: 'French-Algerian philosopher and novelist',
    era: '1913–1960',
    bio: 'Albert Camus was a French-Algerian philosopher, author, dramatist, journalist, world federalist, and political activist. He was awarded the 1957 Nobel Prize in Literature. His philosophy is centred on absurdism — the conflict between the human tendency to seek meaning and the world\'s silence on the matter.',
  },
  {
    id: 'seneca',
    name: 'Seneca the Younger',
    description: 'Roman Stoic philosopher and statesman',
    era: 'c. 4 BC–65 AD',
    bio: 'Lucius Annaeus Seneca, known as Seneca the Younger, was a Roman Stoic philosopher, statesman, dramatist, and humorist. His philosophical writing addresses themes of self-examination, ethics, time, and the nature of a good life.',
  },
  {
    id: 'dostoevsky',
    name: 'Fyodor Dostoevsky',
    description: 'Russian novelist and philosopher',
    era: '1821–1881',
    bio: 'Fyodor Mikhailovich Dostoevsky was a Russian novelist, short story writer, essayist and journalist. His literary works explore human psychology in the troubled political, social, and spiritual atmospheres of 19th-century Russia.',
  },
  {
    id: 'james-baldwin',
    name: 'James Baldwin',
    description: 'American novelist, essayist and activist',
    era: '1924–1987',
    bio: 'James Arthur Baldwin was an American novelist, essayist, playwright, poet, and activist. His essays, as collected in Notes of a Native Son, explore intricacies of racial, sexual, and class distinctions in Western society.',
  },
]

export const QUOTES: Quote[] = [
  {
    id: 'q1',
    content: 'You have power over your mind — not outside events. Realize this, and you will find strength.',
    authorId: 'marcus-aurelius',
    year: 'c. 170 AD',
    categories: ['Philosophy', 'Stoicism'],
    tags: ['mind', 'strength', 'control'],
    language: 'English',
  },
  {
    id: 'q2',
    content: 'The impediment to action advances action. What stands in the way becomes the way.',
    authorId: 'marcus-aurelius',
    year: 'c. 170 AD',
    categories: ['Philosophy', 'Stoicism'],
    tags: ['adversity', 'action', 'resilience'],
    language: 'English',
  },
  {
    id: 'q3',
    content: 'Waste no more time arguing what a good man should be. Be one.',
    authorId: 'marcus-aurelius',
    year: 'c. 170 AD',
    categories: ['Philosophy', 'Wisdom'],
    tags: ['virtue', 'action', 'character'],
    language: 'English',
  },
  {
    id: 'q4',
    content: 'It is not what happens to you, but how you react to it that matters.',
    authorId: 'epictetus',
    year: 'c. 100 AD',
    categories: ['Philosophy', 'Stoicism'],
    tags: ['resilience', 'attitude', 'reaction'],
    language: 'English',
  },
  {
    id: 'q5',
    content: 'Make the best use of what is in your power, and take the rest as it happens.',
    authorId: 'epictetus',
    year: 'c. 100 AD',
    categories: ['Philosophy', 'Stoicism'],
    tags: ['control', 'acceptance', 'wisdom'],
    language: 'English',
  },
  {
    id: 'q6',
    content: 'Know thyself.',
    authorId: 'socrates',
    year: 'c. 400 BC',
    categories: ['Philosophy', 'Ancient Philosophy'],
    tags: ['self-knowledge', 'wisdom', 'introspection'],
    language: 'English',
  },
  {
    id: 'q7',
    content: 'The unexamined life is not worth living.',
    authorId: 'socrates',
    year: 'c. 399 BC',
    categories: ['Philosophy', 'Ancient Philosophy'],
    tags: ['introspection', 'life', 'wisdom'],
    language: 'English',
  },
  {
    id: 'q8',
    content: 'Without music, life would be a mistake.',
    authorId: 'nietzsche',
    year: '1889',
    categories: ['Philosophy', 'Art'],
    tags: ['music', 'life', 'culture'],
    language: 'English',
  },
  {
    id: 'q9',
    content: 'That which does not kill us, makes us stronger.',
    authorId: 'nietzsche',
    year: '1888',
    categories: ['Philosophy', 'Motivation'],
    tags: ['adversity', 'strength', 'resilience'],
    language: 'English',
  },
  {
    id: 'q10',
    content: 'One is not born, but rather becomes, a woman.',
    authorId: 'simone-de-beauvoir',
    year: '1949',
    categories: ['Philosophy', 'Existentialism'],
    tags: ['gender', 'identity', 'society'],
    language: 'English',
  },
  {
    id: 'q11',
    content: 'Change your life today. Don\'t gamble on the future, act now, without delay.',
    authorId: 'simone-de-beauvoir',
    year: '1960',
    categories: ['Motivation', 'Life'],
    tags: ['action', 'change', 'urgency'],
    language: 'English',
  },
  {
    id: 'q12',
    content: 'You cannot find peace by avoiding life.',
    authorId: 'virginia-woolf',
    year: '1930',
    categories: ['Literature', 'Life'],
    tags: ['peace', 'engagement', 'existence'],
    language: 'English',
  },
  {
    id: 'q13',
    content: 'You cannot find peace by avoiding life. Peace is found in the midst of living.',
    authorId: 'virginia-woolf',
    year: '1930',
    categories: ['Literature', 'Life'],
    tags: ['peace', 'living', 'wisdom'],
    language: 'English',
  },
  {
    id: 'q14',
    content: 'In the depth of winter, I finally learned that within me there lay an invincible summer.',
    authorId: 'albert-camus',
    year: '1954',
    categories: ['Philosophy', 'Existentialism'],
    tags: ['resilience', 'inner strength', 'seasons'],
    language: 'English',
  },
  {
    id: 'q15',
    content: 'The only way to deal with an unfree world is to become so absolutely free that your very existence is an act of rebellion.',
    authorId: 'albert-camus',
    year: '1942',
    categories: ['Philosophy', 'Existentialism'],
    tags: ['freedom', 'rebellion', 'existence'],
    language: 'English',
  },
  {
    id: 'q16',
    content: 'We suffer more in imagination than in reality.',
    authorId: 'seneca',
    year: 'c. 60 AD',
    categories: ['Philosophy', 'Stoicism'],
    tags: ['imagination', 'fear', 'mind'],
    language: 'English',
  },
  {
    id: 'q17',
    content: 'Begin at once to live, and count each separate day as a separate life.',
    authorId: 'seneca',
    year: 'c. 60 AD',
    categories: ['Philosophy', 'Life'],
    tags: ['presence', 'living', 'time'],
    language: 'English',
  },
  {
    id: 'q18',
    content: 'The soul is healed by being with children.',
    authorId: 'dostoevsky',
    year: '1880',
    categories: ['Literature', 'Life'],
    tags: ['soul', 'healing', 'innocence'],
    language: 'English',
  },
  {
    id: 'q19',
    content: 'Not all those who wander are lost.',
    authorId: 'james-baldwin',
    year: '1963',
    categories: ['Literature', 'Life'],
    tags: ['identity', 'journey', 'freedom'],
    language: 'English',
  },
  {
    id: 'q20',
    content: 'Not everything that is faced can be changed, but nothing can be changed until it is faced.',
    authorId: 'james-baldwin',
    year: '1962',
    categories: ['Knowledge', 'Life'],
    tags: ['change', 'courage', 'truth'],
    language: 'English',
  },
]

export const CATEGORIES = [
  'Philosophy',
  'Literature',
  'Science',
  'Life',
  'Love',
  'Knowledge',
  'Motivation',
  'Existentialism',
  'Stoicism',
  'Wisdom',
  'Art',
  'Ancient Philosophy',
]

export function getAuthor(id: string) {
  return AUTHORS.find((a) => a.id === id)
}

export function getQuote(id: string) {
  return QUOTES.find((q) => q.id === id)
}

export function getQuotesByAuthor(authorId: string) {
  return QUOTES.filter((q) => q.authorId === authorId)
}

export function getQuotesByCategory(category: string) {
  return QUOTES.filter((q) => q.categories.includes(category))
}

export function searchQuotes(query: string) {
  const q = query.toLowerCase()
  return QUOTES.filter(
    (quote) =>
      quote.content.toLowerCase().includes(q) ||
      getAuthor(quote.authorId)?.name.toLowerCase().includes(q) ||
      quote.categories.some((c) => c.toLowerCase().includes(q)) ||
      quote.tags.some((t) => t.toLowerCase().includes(q)),
  )
}
