import { getAuthor, getQuotesByAuthor } from '../data'

interface AuthorDetailProps {
  authorId: string
  favorites: string[]
  toggleFavorite: (id: string) => void
  navigate: (page: string, extra?: Record<string, string>) => void
}

export default function AuthorDetail({ authorId, favorites, toggleFavorite, navigate }: AuthorDetailProps) {
  const author = getAuthor(authorId)
  if (!author) return null
  const quotes = getQuotesByAuthor(authorId)

  return (
    <main style={{ maxWidth: '680px', margin: '0 auto', padding: '5rem 2rem' }}>
      {/* Back */}
      <button
        onClick={() => navigate('authors')}
        style={{
          background: 'none',
          border: 'none',
          padding: 0,
          fontSize: '0.8125rem',
          color: 'var(--text-tertiary)',
          marginBottom: '3rem',
          display: 'flex',
          alignItems: 'center',
          gap: '6px',
          transition: 'color 0.15s',
        }}
        onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.color = 'var(--text)')}
        onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.color = 'var(--text-tertiary)')}
      >
        ← Authors
      </button>

      {/* Header */}
      <div style={{ marginBottom: '3.5rem', paddingBottom: '3rem', borderBottom: '1px solid var(--border-subtle)' }}>
        <h1
          style={{
            fontFamily: 'Lora, serif',
            fontSize: 'clamp(2rem, 4vw, 3rem)',
            fontWeight: 400,
            letterSpacing: '-0.02em',
            color: 'var(--text)',
            marginBottom: '0.5rem',
          }}
        >
          {author.name}
        </h1>
        <p style={{ fontSize: '0.9375rem', color: 'var(--text-secondary)', marginBottom: '0.25rem' }}>
          {author.description}
        </p>
        <p style={{ fontSize: '0.8125rem', color: 'var(--text-tertiary)', marginBottom: '1.75rem' }}>
          {author.era} · {quotes.length} phrases
        </p>
        <p style={{ fontSize: '0.9375rem', lineHeight: 1.75, color: 'var(--text-secondary)' }}>
          {author.bio}
        </p>
      </div>

      {/* Quotes */}
      <p
        style={{
          fontSize: '0.75rem',
          fontWeight: 600,
          letterSpacing: '0.08em',
          textTransform: 'uppercase',
          color: 'var(--text-tertiary)',
          marginBottom: '1.5rem',
        }}
      >
        Quotes by {author.name}
      </p>
      <div style={{ display: 'flex', flexDirection: 'column' }}>
        {quotes.map((quote, i) => {
          const isFav = favorites.includes(quote.id)
          return (
            <div
              key={quote.id}
              style={{
                padding: '1.75rem 0',
                borderTop: i === 0 ? '1px solid var(--border-subtle)' : 'none',
                borderBottom: '1px solid var(--border-subtle)',
                display: 'flex',
                flexDirection: 'column',
                gap: '1rem',
              }}
            >
              <button
                onClick={() => navigate('quote', { id: quote.id })}
                style={{
                  background: 'none',
                  border: 'none',
                  padding: 0,
                  textAlign: 'left',
                  cursor: 'pointer',
                  transition: 'opacity 0.15s',
                }}
                onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.opacity = '0.6')}
                onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.opacity = '1')}
              >
                <p
                  style={{
                    fontFamily: 'Lora, serif',
                    fontStyle: 'italic',
                    fontSize: '1.0625rem',
                    lineHeight: 1.65,
                    color: 'var(--text)',
                  }}
                >
                  "{quote.content}"
                </p>
              </button>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div style={{ display: 'flex', gap: '0.5rem' }}>
                  {quote.categories.map((c) => (
                    <span
                      key={c}
                      style={{
                        fontSize: '0.6875rem',
                        color: 'var(--text-tertiary)',
                        border: '1px solid var(--border-subtle)',
                        borderRadius: '99px',
                        padding: '2px 10px',
                      }}
                    >
                      {c}
                    </span>
                  ))}
                </div>
                <button
                  onClick={() => toggleFavorite(quote.id)}
                  style={{
                    background: 'none',
                    border: 'none',
                    padding: 0,
                    fontSize: '0.75rem',
                    color: isFav ? 'var(--text)' : 'var(--text-tertiary)',
                    transition: 'color 0.15s',
                  }}
                >
                  {isFav ? '♥' : '♡'}
                </button>
              </div>
            </div>
          )
        })}
      </div>
    </main>
  )
}
