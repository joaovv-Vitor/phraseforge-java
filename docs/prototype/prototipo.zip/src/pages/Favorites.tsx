import { getQuote, getAuthor } from '../data'

interface FavoritesProps {
  favorites: string[]
  toggleFavorite: (id: string) => void
  navigate: (page: string, extra?: Record<string, string>) => void
  copied: string | null
  setCopied: (id: string | null) => void
}

export default function Favorites({
  favorites,
  toggleFavorite,
  navigate,
  copied,
  setCopied,
}: FavoritesProps) {
  const quotes = favorites.map(getQuote).filter(Boolean) as NonNullable<ReturnType<typeof getQuote>>[]

  return (
    <main style={{ maxWidth: '680px', margin: '0 auto', padding: '4rem 2rem' }}>
      <div style={{ marginBottom: '3rem' }}>
        <h1
          style={{
            fontFamily: 'Lora, serif',
            fontSize: 'clamp(2rem, 4vw, 2.75rem)',
            fontWeight: 400,
            letterSpacing: '-0.02em',
            color: 'var(--text)',
            marginBottom: '0.5rem',
          }}
        >
          Favorites
        </h1>
        <p style={{ fontSize: '0.9375rem', color: 'var(--text-secondary)' }}>
          {quotes.length > 0
            ? `${quotes.length} saved ${quotes.length === 1 ? 'phrase' : 'phrases'}`
            : 'Your saved phrases will appear here.'}
        </p>
      </div>

      {quotes.length === 0 && (
        <div
          style={{
            padding: '4rem 0',
            textAlign: 'center',
            borderTop: '1px solid var(--border-subtle)',
          }}
        >
          <p
            style={{
              fontFamily: 'Lora, serif',
              fontStyle: 'italic',
              fontSize: '1.125rem',
              color: 'var(--text-tertiary)',
              marginBottom: '1rem',
            }}
          >
            "Nothing yet."
          </p>
          <button
            onClick={() => navigate('explore')}
            style={{
              background: 'none',
              border: '1px solid var(--border)',
              borderRadius: '99px',
              padding: '8px 20px',
              fontSize: '0.8125rem',
              color: 'var(--text-secondary)',
              transition: 'all 0.15s',
            }}
          >
            Start exploring
          </button>
        </div>
      )}

      <div style={{ display: 'flex', flexDirection: 'column' }}>
        {quotes.map((quote, i) => {
          const author = getAuthor(quote.authorId)
          const copy = () => {
            navigator.clipboard.writeText(`"${quote.content}" — ${author?.name}`)
            setCopied(quote.id)
            setTimeout(() => setCopied(null), 2000)
          }
          return (
            <div
              key={quote.id}
              style={{
                padding: '1.75rem 0',
                borderTop: i === 0 ? '1px solid var(--border-subtle)' : 'none',
                borderBottom: '1px solid var(--border-subtle)',
                display: 'flex',
                flexDirection: 'column',
                gap: '1.25rem',
              }}
            >
              <button
                onClick={() => navigate('quote', { id: quote.id })}
                style={{
                  background: 'none',
                  border: 'none',
                  padding: 0,
                  textAlign: 'left',
                  cursor: 'pointer',
                  transition: 'opacity 0.15s',
                }}
                onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.opacity = '0.6')}
                onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.opacity = '1')}
              >
                <p
                  style={{
                    fontFamily: 'Lora, serif',
                    fontStyle: 'italic',
                    fontSize: '1.0625rem',
                    lineHeight: 1.65,
                    color: 'var(--text)',
                    marginBottom: '0.75rem',
                  }}
                >
                  "{quote.content}"
                </p>
                <p style={{ fontSize: '0.875rem', fontWeight: 500, color: 'var(--text)' }}>
                  — {author?.name}
                </p>
              </button>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div style={{ display: 'flex', gap: '0.5rem' }}>
                  {quote.categories.map((c) => (
                    <span
                      key={c}
                      style={{
                        fontSize: '0.6875rem',
                        color: 'var(--text-tertiary)',
                        border: '1px solid var(--border-subtle)',
                        borderRadius: '99px',
                        padding: '2px 10px',
                      }}
                    >
                      {c}
                    </span>
                  ))}
                </div>
                <div style={{ display: 'flex', gap: '1rem' }}>
                  <button
                    onClick={copy}
                    style={{
                      background: 'none',
                      border: 'none',
                      padding: 0,
                      fontSize: '0.75rem',
                      color: copied === quote.id ? 'var(--text)' : 'var(--text-tertiary)',
                      transition: 'color 0.15s',
                    }}
                  >
                    {copied === quote.id ? '✓' : '⎘'}
                  </button>
                  <button
                    onClick={() => toggleFavorite(quote.id)}
                    style={{
                      background: 'none',
                      border: 'none',
                      padding: 0,
                      fontSize: '0.75rem',
                      color: 'var(--text)',
                      transition: 'opacity 0.15s',
                    }}
                    title="Remove from favorites"
                    onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.opacity = '0.4')}
                    onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.opacity = '1')}
                  >
                    ♥
                  </button>
                </div>
              </div>
            </div>
          )
        })}
      </div>
    </main>
  )
}
