import { useState } from 'react'
import { AUTHORS, getQuotesByAuthor } from '../data'

interface AuthorsProps {
  navigate: (page: string, extra?: Record<string, string>) => void
}

export default function Authors({ navigate }: AuthorsProps) {
  const [query, setQuery] = useState('')

  const results = AUTHORS.filter(
    (a) =>
      query === '' ||
      a.name.toLowerCase().includes(query.toLowerCase()) ||
      a.description.toLowerCase().includes(query.toLowerCase()),
  )

  return (
    <main style={{ maxWidth: '720px', margin: '0 auto', padding: '4rem 2rem' }}>
      <div style={{ marginBottom: '3rem' }}>
        <h1
          style={{
            fontFamily: 'Lora, serif',
            fontSize: 'clamp(2rem, 4vw, 2.75rem)',
            fontWeight: 400,
            letterSpacing: '-0.02em',
            color: 'var(--text)',
            marginBottom: '0.5rem',
          }}
        >
          Authors
        </h1>
        <p style={{ fontSize: '0.9375rem', color: 'var(--text-secondary)' }}>
          Explore the thinkers behind the words.
        </p>
      </div>

      {/* Search */}
      <div style={{ position: 'relative', marginBottom: '2.5rem', maxWidth: '400px' }}>
        <span
          style={{
            position: 'absolute',
            left: '14px',
            top: '50%',
            transform: 'translateY(-50%)',
            color: 'var(--text-tertiary)',
            fontSize: '0.875rem',
            pointerEvents: 'none',
          }}
        >
          ⌕
        </span>
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search authors..."
          style={{
            width: '100%',
            background: 'var(--bg-card)',
            border: '1px solid var(--border)',
            borderRadius: 'var(--radius)',
            padding: '10px 14px 10px 36px',
            fontSize: '0.875rem',
            color: 'var(--text)',
            outline: 'none',
            transition: 'border-color 0.15s',
          }}
          onFocus={(e) => (e.target.style.borderColor = 'var(--text-secondary)')}
          onBlur={(e) => (e.target.style.borderColor = 'var(--border)')}
        />
      </div>

      {/* List */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
        {results.map((author, i) => {
          const quoteCount = getQuotesByAuthor(author.id).length
          return (
            <button
              key={author.id}
              onClick={() => navigate('author', { id: author.id })}
              style={{
                background: 'none',
                border: 'none',
                padding: '1.5rem 0',
                borderTop: i === 0 ? '1px solid var(--border-subtle)' : 'none',
                borderBottom: '1px solid var(--border-subtle)',
                textAlign: 'left',
                cursor: 'pointer',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'baseline',
                gap: '2rem',
                transition: 'opacity 0.15s',
              }}
              onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.opacity = '0.6')}
              onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.opacity = '1')}
            >
              <div>
                <p
                  style={{
                    fontFamily: 'Lora, serif',
                    fontSize: '1.125rem',
                    fontWeight: 400,
                    color: 'var(--text)',
                    marginBottom: '2px',
                  }}
                >
                  {author.name}
                </p>
                <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)' }}>
                  {author.description}
                </p>
              </div>
              <span
                style={{
                  fontSize: '0.75rem',
                  color: 'var(--text-tertiary)',
                  whiteSpace: 'nowrap',
                  flexShrink: 0,
                }}
              >
                {quoteCount} {quoteCount === 1 ? 'phrase' : 'phrases'}
              </span>
            </button>
          )
        })}
      </div>
    </main>
  )
}
