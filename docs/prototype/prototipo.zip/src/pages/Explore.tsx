import { useState } from 'react'
import { QUOTES, CATEGORIES, getAuthor } from '../data'

interface ExploreProps {
  favorites: string[]
  toggleFavorite: (id: string) => void
  navigate: (page: string, extra?: Record<string, string>) => void
  copied: string | null
  setCopied: (id: string | null) => void
}

export default function Explore({ favorites, toggleFavorite, navigate, copied, setCopied }: ExploreProps) {
  const [query, setQuery] = useState('')
  const [activeFilter, setActiveFilter] = useState('All')

  const filters = ['All', ...CATEGORIES.slice(0, 7)]

  const results = QUOTES.filter((q) => {
    const author = getAuthor(q.authorId)
    const matchesQuery =
      query === '' ||
      q.content.toLowerCase().includes(query.toLowerCase()) ||
      author?.name.toLowerCase().includes(query.toLowerCase()) ||
      q.categories.some((c) => c.toLowerCase().includes(query.toLowerCase()))
    const matchesFilter =
      activeFilter === 'All' || q.categories.includes(activeFilter)
    return matchesQuery && matchesFilter
  })

  const copy = (id: string, content: string, authorName: string) => {
    navigator.clipboard.writeText(`"${content}" — ${authorName}`)
    setCopied(id)
    setTimeout(() => setCopied(null), 2000)
  }

  return (
    <main style={{ maxWidth: '1040px', margin: '0 auto', padding: '4rem 2rem' }}>
      {/* Heading */}
      <div style={{ marginBottom: '3rem' }}>
        <h1
          style={{
            fontFamily: 'Lora, serif',
            fontSize: 'clamp(2rem, 4vw, 2.75rem)',
            fontWeight: 400,
            letterSpacing: '-0.02em',
            color: 'var(--text)',
            marginBottom: '0.5rem',
          }}
        >
          Explore
        </h1>
        <p style={{ fontSize: '0.9375rem', color: 'var(--text-secondary)' }}>
          Discover ideas, thoughts and words from different thinkers.
        </p>
      </div>

      {/* Search */}
      <div style={{ position: 'relative', marginBottom: '1.75rem', maxWidth: '480px' }}>
        <span
          style={{
            position: 'absolute',
            left: '14px',
            top: '50%',
            transform: 'translateY(-50%)',
            color: 'var(--text-tertiary)',
            fontSize: '0.875rem',
            pointerEvents: 'none',
          }}
        >
          ⌕
        </span>
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search phrases, authors or topics..."
          style={{
            width: '100%',
            background: 'var(--bg-card)',
            border: '1px solid var(--border)',
            borderRadius: 'var(--radius)',
            padding: '10px 14px 10px 36px',
            fontSize: '0.875rem',
            color: 'var(--text)',
            outline: 'none',
            transition: 'border-color 0.15s',
          }}
          onFocus={(e) => (e.target.style.borderColor = 'var(--text-secondary)')}
          onBlur={(e) => (e.target.style.borderColor = 'var(--border)')}
        />
      </div>

      {/* Filters */}
      <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap', marginBottom: '2.5rem' }}>
        {filters.map((f) => (
          <button
            key={f}
            onClick={() => setActiveFilter(f)}
            style={{
              background: activeFilter === f ? 'var(--text)' : 'none',
              color: activeFilter === f ? 'var(--bg)' : 'var(--text-secondary)',
              border: activeFilter === f ? '1px solid var(--text)' : '1px solid var(--border)',
              borderRadius: '99px',
              padding: '5px 14px',
              fontSize: '0.8125rem',
              fontWeight: activeFilter === f ? 500 : 400,
              transition: 'all 0.15s',
            }}
          >
            {f}
          </button>
        ))}
      </div>

      {/* Count */}
      <p style={{ fontSize: '0.8125rem', color: 'var(--text-tertiary)', marginBottom: '2rem' }}>
        {results.length} {results.length === 1 ? 'phrase' : 'phrases'}
      </p>

      {/* Grid */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
          gap: '1px',
          border: '1px solid var(--border-subtle)',
          borderRadius: 'var(--radius)',
          overflow: 'hidden',
          background: 'var(--border-subtle)',
        }}
      >
        {results.map((quote) => {
          const author = getAuthor(quote.authorId)
          const isFav = favorites.includes(quote.id)
          return (
            <div
              key={quote.id}
              style={{
                background: 'var(--bg)',
                padding: '2rem',
                display: 'flex',
                flexDirection: 'column',
                gap: '1.25rem',
                cursor: 'pointer',
                transition: 'background 0.15s',
              }}
              onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.background = 'var(--bg-card)')}
              onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.background = 'var(--bg)')}
              onClick={() => navigate('quote', { id: quote.id })}
            >
              <p
                style={{
                  fontFamily: 'Lora, serif',
                  fontStyle: 'italic',
                  fontSize: '1rem',
                  lineHeight: 1.65,
                  color: 'var(--text)',
                  flex: 1,
                }}
              >
                "{quote.content}"
              </p>
              <div>
                <p style={{ fontSize: '0.875rem', fontWeight: 500, color: 'var(--text)', marginBottom: '3px' }}>
                  — {author?.name}
                </p>
                <p style={{ fontSize: '0.75rem', color: 'var(--text-tertiary)' }}>
                  {quote.categories.join(' · ')}
                </p>
              </div>
              <div
                style={{ display: 'flex', gap: '1rem' }}
                onClick={(e) => e.stopPropagation()}
              >
                <button
                  onClick={() => toggleFavorite(quote.id)}
                  style={{
                    background: 'none',
                    border: 'none',
                    padding: 0,
                    fontSize: '0.75rem',
                    color: isFav ? 'var(--text)' : 'var(--text-tertiary)',
                    transition: 'color 0.15s',
                  }}
                >
                  {isFav ? '♥' : '♡'} {isFav ? 'Saved' : 'Save'}
                </button>
                <button
                  onClick={() => copy(quote.id, quote.content, author?.name ?? '')}
                  style={{
                    background: 'none',
                    border: 'none',
                    padding: 0,
                    fontSize: '0.75rem',
                    color: copied === quote.id ? 'var(--text)' : 'var(--text-tertiary)',
                    transition: 'color 0.15s',
                  }}
                >
                  {copied === quote.id ? '✓ Copied' : '⎘ Copy'}
                </button>
              </div>
            </div>
          )
        })}
      </div>

      {results.length === 0 && (
        <div style={{ textAlign: 'center', padding: '4rem', color: 'var(--text-tertiary)' }}>
          <p style={{ fontFamily: 'Lora, serif', fontSize: '1.125rem', marginBottom: '0.5rem' }}>
            No phrases found.
          </p>
          <p style={{ fontSize: '0.875rem' }}>Try a different search or filter.</p>
        </div>
      )}
    </main>
  )
}
