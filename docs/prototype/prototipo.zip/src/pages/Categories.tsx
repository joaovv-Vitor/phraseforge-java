import { CATEGORIES, getQuotesByCategory } from '../data'

interface CategoriesProps {
  navigate: (page: string, extra?: Record<string, string>) => void
}

export default function Categories({ navigate }: CategoriesProps) {
  return (
    <main style={{ maxWidth: '680px', margin: '0 auto', padding: '4rem 2rem' }}>
      <div style={{ marginBottom: '3.5rem' }}>
        <h1
          style={{
            fontFamily: 'Lora, serif',
            fontSize: 'clamp(2rem, 4vw, 2.75rem)',
            fontWeight: 400,
            letterSpacing: '-0.02em',
            color: 'var(--text)',
          }}
        >
          Categories
        </h1>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column' }}>
        {CATEGORIES.map((cat, i) => {
          const count = getQuotesByCategory(cat).length
          return (
            <button
              key={cat}
              onClick={() => navigate('explore')}
              style={{
                background: 'none',
                border: 'none',
                padding: '1.25rem 0',
                borderTop: i === 0 ? '1px solid var(--border-subtle)' : 'none',
                borderBottom: '1px solid var(--border-subtle)',
                textAlign: 'left',
                cursor: 'pointer',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                transition: 'opacity 0.15s',
              }}
              onMouseEnter={(e) => {
                const el = e.currentTarget as HTMLElement
                el.style.opacity = '0.5'
              }}
              onMouseLeave={(e) => {
                const el = e.currentTarget as HTMLElement
                el.style.opacity = '1'
              }}
            >
              <span
                style={{
                  fontFamily: 'Lora, serif',
                  fontSize: '1.25rem',
                  fontWeight: 400,
                  color: 'var(--text)',
                  letterSpacing: '-0.01em',
                }}
              >
                {cat}
              </span>
              <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                <span style={{ fontSize: '0.75rem', color: 'var(--text-tertiary)' }}>
                  {count} {count === 1 ? 'phrase' : 'phrases'}
                </span>
                <span style={{ fontSize: '0.875rem', color: 'var(--text-tertiary)' }}>→</span>
              </div>
            </button>
          )
        })}
      </div>
    </main>
  )
}
