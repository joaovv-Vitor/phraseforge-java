import { getQuote, getAuthor, getQuotesByAuthor } from '../data'

interface QuoteDetailProps {
  quoteId: string
  favorites: string[]
  toggleFavorite: (id: string) => void
  navigate: (page: string, extra?: Record<string, string>) => void
  copied: string | null
  setCopied: (id: string | null) => void
}

export default function QuoteDetail({
  quoteId,
  favorites,
  toggleFavorite,
  navigate,
  copied,
  setCopied,
}: QuoteDetailProps) {
  const quote = getQuote(quoteId)
  if (!quote) return null
  const author = getAuthor(quote.authorId)
  const related = getQuotesByAuthor(quote.authorId).filter((q) => q.id !== quoteId).slice(0, 4)
  const isFav = favorites.includes(quote.id)

  const copy = () => {
    navigator.clipboard.writeText(`"${quote.content}" — ${author?.name}`)
    setCopied(quote.id)
    setTimeout(() => setCopied(null), 2000)
  }

  return (
    <main style={{ maxWidth: '680px', margin: '0 auto', padding: '5rem 2rem' }}>
      {/* Back */}
      <button
        onClick={() => navigate('explore')}
        style={{
          background: 'none',
          border: 'none',
          padding: 0,
          fontSize: '0.8125rem',
          color: 'var(--text-tertiary)',
          marginBottom: '3rem',
          display: 'flex',
          alignItems: 'center',
          gap: '6px',
          transition: 'color 0.15s',
        }}
        onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.color = 'var(--text)')}
        onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.color = 'var(--text-tertiary)')}
      >
        ← Back
      </button>

      {/* Category */}
      <p
        style={{
          fontSize: '0.6875rem',
          fontWeight: 600,
          letterSpacing: '0.1em',
          textTransform: 'uppercase',
          color: 'var(--text-tertiary)',
          marginBottom: '2rem',
        }}
      >
        {quote.categories[0]}
      </p>

      {/* Quote */}
      <blockquote
        style={{
          fontFamily: 'Lora, serif',
          fontSize: 'clamp(1.375rem, 3vw, 2rem)',
          fontStyle: 'italic',
          fontWeight: 400,
          lineHeight: 1.55,
          letterSpacing: '-0.015em',
          color: 'var(--text)',
          margin: '0 0 2.5rem',
        }}
      >
        "{quote.content}"
      </blockquote>

      {/* Author */}
      <div style={{ marginBottom: '3rem' }}>
        <button
          onClick={() => navigate('author', { id: quote.authorId })}
          style={{
            background: 'none',
            border: 'none',
            padding: 0,
            fontSize: '1rem',
            fontWeight: 500,
            color: 'var(--text)',
            display: 'block',
            marginBottom: '3px',
            transition: 'opacity 0.15s',
            textAlign: 'left',
          }}
          onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.opacity = '0.6')}
          onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.opacity = '1')}
        >
          — {author?.name}
        </button>
        <span style={{ fontSize: '0.8125rem', color: 'var(--text-tertiary)' }}>{quote.year}</span>
      </div>

      {/* Tags */}
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem', marginBottom: '3rem' }}>
        {[...quote.categories, ...quote.tags].map((tag) => (
          <span
            key={tag}
            style={{
              border: '1px solid var(--border)',
              borderRadius: '99px',
              padding: '3px 12px',
              fontSize: '0.75rem',
              color: 'var(--text-secondary)',
            }}
          >
            {tag}
          </span>
        ))}
        <span style={{ fontSize: '0.75rem', color: 'var(--text-tertiary)', alignSelf: 'center', marginLeft: '4px' }}>
          {quote.year}
        </span>
      </div>

      {/* Actions */}
      <div
        style={{
          display: 'flex',
          gap: '0.75rem',
          paddingTop: '2rem',
          borderTop: '1px solid var(--border-subtle)',
          marginBottom: '5rem',
        }}
      >
        <ActionButton onClick={() => toggleFavorite(quote.id)} active={isFav}>
          {isFav ? '♥ Saved' : '♡ Favorite'}
        </ActionButton>
        <ActionButton onClick={copy}>
          {copied === quote.id ? '✓ Copied' : '⎘ Copy Quote'}
        </ActionButton>
        <ActionButton
          onClick={() => {
            navigator.clipboard.writeText(window.location.href)
          }}
        >
          ↗ Share
        </ActionButton>
      </div>

      {/* Related */}
      {related.length > 0 && (
        <section>
          <p
            style={{
              fontSize: '0.75rem',
              fontWeight: 600,
              letterSpacing: '0.08em',
              textTransform: 'uppercase',
              color: 'var(--text-tertiary)',
              marginBottom: '1.5rem',
            }}
          >
            More from {author?.name}
          </p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
            {related.map((q, i) => (
              <button
                key={q.id}
                onClick={() => navigate('quote', { id: q.id })}
                style={{
                  background: 'none',
                  border: 'none',
                  padding: '1.25rem 0',
                  borderTop: i === 0 ? '1px solid var(--border-subtle)' : 'none',
                  borderBottom: '1px solid var(--border-subtle)',
                  textAlign: 'left',
                  cursor: 'pointer',
                  transition: 'opacity 0.15s',
                }}
                onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.opacity = '0.6')}
                onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.opacity = '1')}
              >
                <p
                  style={{
                    fontFamily: 'Lora, serif',
                    fontStyle: 'italic',
                    fontSize: '1rem',
                    lineHeight: 1.6,
                    color: 'var(--text)',
                  }}
                >
                  "{q.content}"
                </p>
              </button>
            ))}
          </div>
        </section>
      )}
    </main>
  )
}

function ActionButton({
  children,
  onClick,
  active,
}: {
  children: React.ReactNode
  onClick: () => void
  active?: boolean
}) {
  return (
    <button
      onClick={onClick}
      style={{
        background: active ? 'var(--text)' : 'none',
        border: '1px solid var(--border)',
        borderColor: active ? 'var(--text)' : 'var(--border)',
        borderRadius: 'var(--radius)',
        padding: '8px 16px',
        fontSize: '0.8125rem',
        fontWeight: active ? 500 : 400,
        color: active ? 'var(--bg)' : 'var(--text-secondary)',
        transition: 'all 0.15s',
      }}
      onMouseEnter={(e) => {
        if (!active) {
          (e.currentTarget as HTMLElement).style.borderColor = 'var(--text-secondary)'
          ;(e.currentTarget as HTMLElement).style.color = 'var(--text)'
        }
      }}
      onMouseLeave={(e) => {
        if (!active) {
          (e.currentTarget as HTMLElement).style.borderColor = 'var(--border)'
          ;(e.currentTarget as HTMLElement).style.color = 'var(--text-secondary)'
        }
      }}
    >
      {children}
    </button>
  )
}
