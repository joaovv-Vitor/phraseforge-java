import { useState, useEffect } from 'react'
import { QUOTES, getAuthor } from '../data'

interface HomeProps {
  favorites: string[]
  toggleFavorite: (id: string) => void
  navigate: (page: string, extra?: Record<string, string>) => void
  copied: string | null
  setCopied: (id: string | null) => void
}

export default function Home({ favorites, toggleFavorite, navigate, copied, setCopied }: HomeProps) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [visible, setVisible] = useState(true)

  const quote = QUOTES[currentIndex]
  const author = getAuthor(quote.authorId)

  const nextQuote = () => {
    setVisible(false)
    setTimeout(() => {
      setCurrentIndex((i) => (i + 1) % QUOTES.length)
      setVisible(true)
    }, 280)
  }

  const copyQuote = () => {
    navigator.clipboard.writeText(`"${quote.content}" — ${author?.name}`)
    setCopied(quote.id)
    setTimeout(() => setCopied(null), 2000)
  }

  const isFav = favorites.includes(quote.id)

  useEffect(() => {
    setVisible(true)
  }, [currentIndex])

  return (
    <main
      style={{
        minHeight: 'calc(100vh - 52px)',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '4rem 2rem',
      }}
    >
      <div
        style={{
          maxWidth: '680px',
          width: '100%',
          opacity: visible ? 1 : 0,
          transform: visible ? 'translateY(0)' : 'translateY(6px)',
          transition: 'opacity 0.28s ease, transform 0.28s ease',
        }}
      >
        {/* Category */}
        <p
          style={{
            fontSize: '0.6875rem',
            fontWeight: 600,
            letterSpacing: '0.1em',
            textTransform: 'uppercase',
            color: 'var(--text-tertiary)',
            marginBottom: '2.5rem',
          }}
        >
          {quote.categories[0]}
        </p>

        {/* Quote */}
        <blockquote
          style={{
            fontFamily: 'Lora, serif',
            fontSize: 'clamp(1.375rem, 3vw, 2rem)',
            fontWeight: 400,
            fontStyle: 'italic',
            lineHeight: 1.55,
            letterSpacing: '-0.015em',
            color: 'var(--text)',
            margin: 0,
            marginBottom: '2.5rem',
          }}
        >
          "{quote.content}"
        </blockquote>

        {/* Attribution */}
        <div style={{ marginBottom: '3.5rem' }}>
          <button
            onClick={() => navigate('author', { id: quote.authorId })}
            style={{
              background: 'none',
              border: 'none',
              padding: 0,
              fontSize: '0.9375rem',
              fontWeight: 500,
              color: 'var(--text)',
              display: 'block',
              marginBottom: '3px',
              textAlign: 'left',
              textDecoration: 'none',
              transition: 'opacity 0.15s',
            }}
            onMouseEnter={(e) => ((e.target as HTMLElement).style.opacity = '0.6')}
            onMouseLeave={(e) => ((e.target as HTMLElement).style.opacity = '1')}
          >
            — {author?.name}
          </button>
          <span
            style={{
              fontSize: '0.8125rem',
              color: 'var(--text-tertiary)',
            }}
          >
            {quote.year}
          </span>
        </div>

        {/* Actions */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '1.5rem',
            marginBottom: '4rem',
          }}
        >
          <ActionBtn
            onClick={() => toggleFavorite(quote.id)}
            active={isFav}
            icon={isFav ? '♥' : '♡'}
            label={isFav ? 'Saved' : 'Favorite'}
          />
          <ActionBtn
            onClick={() => {
              const url = window.location.href
              navigator.clipboard.writeText(url)
            }}
            icon="↗"
            label="Share"
          />
          <ActionBtn
            onClick={copyQuote}
            icon={copied === quote.id ? '✓' : '⎘'}
            label={copied === quote.id ? 'Copied' : 'Copy'}
          />
          <ActionBtn
            onClick={() => navigate('quote', { id: quote.id })}
            icon="→"
            label="View"
          />
        </div>

        {/* New quote */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '1.5rem' }}>
          <button
            onClick={nextQuote}
            style={{
              background: 'none',
              border: '1px solid var(--border)',
              borderRadius: '99px',
              padding: '9px 22px',
              fontSize: '0.8125rem',
              fontWeight: 500,
              color: 'var(--text)',
              letterSpacing: '0.01em',
              transition: 'all 0.15s',
            }}
            onMouseEnter={(e) => {
              const el = e.currentTarget
              el.style.background = 'var(--text)'
              el.style.color = 'var(--bg)'
            }}
            onMouseLeave={(e) => {
              const el = e.currentTarget
              el.style.background = 'none'
              el.style.color = 'var(--text)'
            }}
          >
            New Quote
          </button>
          <span style={{ fontSize: '0.8125rem', color: 'var(--text-tertiary)' }}>
            {currentIndex + 1} / {QUOTES.length}
          </span>
        </div>
      </div>
    </main>
  )
}

function ActionBtn({
  onClick,
  icon,
  label,
  active,
}: {
  onClick: () => void
  icon: string
  label: string
  active?: boolean
}) {
  return (
    <button
      onClick={onClick}
      style={{
        background: 'none',
        border: 'none',
        padding: 0,
        display: 'flex',
        alignItems: 'center',
        gap: '6px',
        fontSize: '0.8125rem',
        fontWeight: active ? 500 : 400,
        color: active ? 'var(--text)' : 'var(--text-secondary)',
        transition: 'color 0.15s',
      }}
      onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.color = 'var(--text)')}
      onMouseLeave={(e) =>
        ((e.currentTarget as HTMLElement).style.color = active
          ? 'var(--text)'
          : 'var(--text-secondary)')
      }
    >
      <span style={{ fontSize: '0.875rem' }}>{icon}</span>
      {label}
    </button>
  )
}
