import { useState } from 'react'
import { searchQuotes, getAuthor } from '../data'

interface SearchProps {
  favorites: string[]
  toggleFavorite: (id: string) => void
  navigate: (page: string, extra?: Record<string, string>) => void
  copied: string | null
  setCopied: (id: string | null) => void
}

export default function Search({ favorites, toggleFavorite, navigate, copied, setCopied }: SearchProps) {
  const [query, setQuery] = useState('')
  const results = query.trim().length > 1 ? searchQuotes(query) : []

  const copy = (id: string, content: string, authorName: string) => {
    navigator.clipboard.writeText(`"${content}" — ${authorName}`)
    setCopied(id)
    setTimeout(() => setCopied(null), 2000)
  }

  return (
    <main
      style={{
        maxWidth: '640px',
        margin: '0 auto',
        padding: '5rem 2rem',
        minHeight: 'calc(100vh - 52px)',
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      {/* Heading */}
      <h1
        style={{
          fontFamily: 'Lora, serif',
          fontSize: 'clamp(1.5rem, 3vw, 2.25rem)',
          fontWeight: 400,
          letterSpacing: '-0.02em',
          color: 'var(--text)',
          textAlign: 'center',
          marginBottom: '2.5rem',
        }}
      >
        Search PhraseForge
      </h1>

      {/* Search input */}
      <div style={{ position: 'relative', marginBottom: '3rem' }}>
        <span
          style={{
            position: 'absolute',
            left: '16px',
            top: '50%',
            transform: 'translateY(-50%)',
            color: 'var(--text-tertiary)',
            fontSize: '1rem',
            pointerEvents: 'none',
          }}
        >
          ⌕
        </span>
        <input
          autoFocus
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search for a phrase, author or topic..."
          style={{
            width: '100%',
            background: 'var(--bg-card)',
            border: '1px solid var(--border)',
            borderRadius: 'var(--radius)',
            padding: '14px 16px 14px 44px',
            fontSize: '1rem',
            color: 'var(--text)',
            outline: 'none',
            transition: 'border-color 0.15s',
          }}
          onFocus={(e) => (e.target.style.borderColor = 'var(--text-secondary)')}
          onBlur={(e) => (e.target.style.borderColor = 'var(--border)')}
        />
      </div>

      {/* Results */}
      {query.trim().length > 1 && (
        <>
          <p style={{ fontSize: '0.8125rem', color: 'var(--text-tertiary)', marginBottom: '1.5rem' }}>
            {results.length} {results.length === 1 ? 'result' : 'results'} for "{query}"
          </p>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            {results.map((quote, i) => {
              const author = getAuthor(quote.authorId)
              const isFav = favorites.includes(quote.id)
              return (
                <div
                  key={quote.id}
                  style={{
                    padding: '1.75rem 0',
                    borderTop: i === 0 ? '1px solid var(--border-subtle)' : 'none',
                    borderBottom: '1px solid var(--border-subtle)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '1rem',
                  }}
                >
                  <button
                    onClick={() => navigate('quote', { id: quote.id })}
                    style={{
                      background: 'none',
                      border: 'none',
                      padding: 0,
                      textAlign: 'left',
                      cursor: 'pointer',
                      transition: 'opacity 0.15s',
                    }}
                    onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.opacity = '0.6')}
                    onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.opacity = '1')}
                  >
                    <p
                      style={{
                        fontFamily: 'Lora, serif',
                        fontStyle: 'italic',
                        fontSize: '1.0625rem',
                        lineHeight: 1.65,
                        color: 'var(--text)',
                        marginBottom: '0.5rem',
                      }}
                    >
                      "{quote.content}"
                    </p>
                    <p style={{ fontSize: '0.875rem', fontWeight: 500, color: 'var(--text-secondary)' }}>
                      — {author?.name}
                    </p>
                  </button>
                  <div style={{ display: 'flex', gap: '1rem' }}>
                    <button
                      onClick={() => toggleFavorite(quote.id)}
                      style={{
                        background: 'none',
                        border: 'none',
                        padding: 0,
                        fontSize: '0.75rem',
                        color: isFav ? 'var(--text)' : 'var(--text-tertiary)',
                        transition: 'color 0.15s',
                      }}
                    >
                      {isFav ? '♥ Saved' : '♡ Save'}
                    </button>
                    <button
                      onClick={() => copy(quote.id, quote.content, author?.name ?? '')}
                      style={{
                        background: 'none',
                        border: 'none',
                        padding: 0,
                        fontSize: '0.75rem',
                        color: copied === quote.id ? 'var(--text)' : 'var(--text-tertiary)',
                        transition: 'color 0.15s',
                      }}
                    >
                      {copied === quote.id ? '✓ Copied' : '⎘ Copy'}
                    </button>
                  </div>
                </div>
              )
            })}
            {results.length === 0 && (
              <div
                style={{
                  padding: '3rem 0',
                  borderTop: '1px solid var(--border-subtle)',
                  textAlign: 'center',
                }}
              >
                <p style={{ fontFamily: 'Lora, serif', fontStyle: 'italic', color: 'var(--text-tertiary)', fontSize: '1rem' }}>
                  No results found.
                </p>
              </div>
            )}
          </div>
        </>
      )}

      {query.trim().length === 0 && (
        <div style={{ textAlign: 'center', paddingTop: '2rem', opacity: 0.5 }}>
          <p style={{ fontSize: '0.875rem', color: 'var(--text-tertiary)' }}>
            Search by phrase, author, category, or tag.
          </p>
        </div>
      )}
    </main>
  )
}
