import { useState } from 'react'
import { getAuthor, QUOTES } from '../data'

// Curated "top of the week" — fixed ids with mocked favorite counts
const WEEKLY = [
  { id: 'q14', count: 847 },
  { id: 'q4',  count: 712 },
  { id: 'q1',  count: 634 },
  { id: 'q7',  count: 581 },
  { id: 'q16', count: 498 },
  { id: 'q15', count: 441 },
  { id: 'q20', count: 389 },
  { id: 'q17', count: 312 },
  { id: 'q9',  count: 274 },
  { id: 'q6',  count: 198 },
]

interface WeeklyProps {
  favorites: string[]
  toggleFavorite: (id: string) => void
  navigate: (page: string, extra?: Record<string, string>) => void
  copied: string | null
  setCopied: (id: string | null) => void
}

export default function Weekly({ favorites, toggleFavorite, navigate, copied, setCopied }: WeeklyProps) {
  const [highlight, setHighlight] = useState<string | null>(null)

  const copy = (id: string, content: string, authorName: string) => {
    navigator.clipboard.writeText(`"${content}" — ${authorName}`)
    setCopied(id)
    setTimeout(() => setCopied(null), 2000)
  }

  // Week range label
  const now = new Date()
  const day = now.getDay()
  const monday = new Date(now)
  monday.setDate(now.getDate() - ((day + 6) % 7))
  const sunday = new Date(monday)
  sunday.setDate(monday.getDate() + 6)
  const fmt = (d: Date) =>
    d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
  const weekLabel = `${fmt(monday)} – ${fmt(sunday)}, ${now.getFullYear()}`

  return (
    <main style={{ maxWidth: '720px', margin: '0 auto', padding: '4rem 2rem 5rem' }}>
      {/* Header */}
      <div style={{ marginBottom: '3.5rem' }}>
        <p
          style={{
            fontSize: '0.6875rem',
            fontWeight: 600,
            letterSpacing: '0.1em',
            textTransform: 'uppercase',
            color: 'var(--text-tertiary)',
            marginBottom: '0.875rem',
          }}
        >
          Week of {weekLabel}
        </p>
        <h1
          style={{
            fontFamily: 'Lora, serif',
            fontSize: 'clamp(2rem, 4vw, 2.75rem)',
            fontWeight: 400,
            letterSpacing: '-0.02em',
            color: 'var(--text)',
            marginBottom: '0.625rem',
          }}
        >
          Most Favorited
        </h1>
        <p style={{ fontSize: '0.9375rem', color: 'var(--text-secondary)', maxWidth: '420px', lineHeight: 1.6 }}>
          The phrases readers saved most this week, ranked by community favorites.
        </p>
      </div>

      {/* Top 3 podium — editorial emphasis */}
      <div style={{ marginBottom: '3rem' }}>
        {WEEKLY.slice(0, 3).map((entry, i) => {
          const quote = QUOTES.find((q) => q.id === entry.id)
          if (!quote) return null
          const author = getAuthor(quote.authorId)
          const isFav = favorites.includes(quote.id)
          const isHovered = highlight === quote.id

          return (
            <div
              key={quote.id}
              style={{
                display: 'grid',
                gridTemplateColumns: '48px 1fr',
                gap: '1.5rem',
                padding: '2rem 0',
                borderTop: i === 0 ? '1px solid var(--border-subtle)' : 'none',
                borderBottom: '1px solid var(--border-subtle)',
                cursor: 'pointer',
                transition: 'opacity 0.15s',
                opacity: isHovered ? 0.6 : 1,
              }}
              onMouseEnter={() => setHighlight(quote.id)}
              onMouseLeave={() => setHighlight(null)}
              onClick={() => navigate('quote', { id: quote.id })}
            >
              {/* Rank */}
              <div
                style={{
                  paddingTop: '3px',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'flex-start',
                  gap: '4px',
                }}
              >
                <span
                  style={{
                    fontFamily: 'Lora, serif',
                    fontSize: i === 0 ? '2rem' : '1.375rem',
                    fontWeight: 400,
                    color: i === 0 ? 'var(--text)' : 'var(--text-tertiary)',
                    lineHeight: 1,
                    letterSpacing: '-0.02em',
                  }}
                >
                  {String(i + 1).padStart(2, '0')}
                </span>
                {i === 0 && (
                  <span
                    style={{
                      fontSize: '0.625rem',
                      fontWeight: 600,
                      letterSpacing: '0.08em',
                      textTransform: 'uppercase',
                      color: 'var(--text-tertiary)',
                    }}
                  >
                    Top
                  </span>
                )}
              </div>

              {/* Content */}
              <div>
                <p
                  style={{
                    fontFamily: 'Lora, serif',
                    fontStyle: 'italic',
                    fontSize: i === 0 ? '1.25rem' : '1.0625rem',
                    fontWeight: 400,
                    lineHeight: 1.6,
                    color: 'var(--text)',
                    marginBottom: '1rem',
                  }}
                >
                  "{quote.content}"
                </p>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.75rem' }}>
                  <div>
                    <p style={{ fontSize: '0.875rem', fontWeight: 500, color: 'var(--text)', marginBottom: '2px' }}>
                      — {author?.name}
                    </p>
                    <p style={{ fontSize: '0.75rem', color: 'var(--text-tertiary)' }}>
                      {quote.categories.join(' · ')}
                    </p>
                  </div>
                  <div
                    style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}
                    onClick={(e) => e.stopPropagation()}
                  >
                    <span style={{ fontSize: '0.75rem', color: 'var(--text-tertiary)', display: 'flex', alignItems: 'center', gap: '4px' }}>
                      <span style={{ fontSize: '0.875rem' }}>♥</span>
                      {entry.count.toLocaleString()}
                    </span>
                    <button
                      onClick={() => toggleFavorite(quote.id)}
                      style={{
                        background: isFav ? 'var(--text)' : 'none',
                        color: isFav ? 'var(--bg)' : 'var(--text-secondary)',
                        border: '1px solid var(--border)',
                        borderColor: isFav ? 'var(--text)' : 'var(--border)',
                        borderRadius: '99px',
                        padding: '4px 12px',
                        fontSize: '0.75rem',
                        fontWeight: isFav ? 500 : 400,
                        display: 'flex',
                        alignItems: 'center',
                        gap: '5px',
                        transition: 'all 0.15s',
                      }}
                    >
                      {isFav ? '♥ Saved' : '♡ Save'}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )
        })}
      </div>

      {/* Ranks 4–10 — compact list */}
      <p
        style={{
          fontSize: '0.6875rem',
          fontWeight: 600,
          letterSpacing: '0.1em',
          textTransform: 'uppercase',
          color: 'var(--text-tertiary)',
          marginBottom: '1.25rem',
        }}
      >
        Also trending
      </p>
      <div style={{ display: 'flex', flexDirection: 'column' }}>
        {WEEKLY.slice(3).map((entry, i) => {
          const quote = QUOTES.find((q) => q.id === entry.id)
          if (!quote) return null
          const author = getAuthor(quote.authorId)
          const isFav = favorites.includes(quote.id)
          const isHovered = highlight === quote.id

          return (
            <div
              key={quote.id}
              style={{
                display: 'grid',
                gridTemplateColumns: '40px 1fr auto',
                gap: '1.25rem',
                padding: '1.125rem 0',
                borderTop: i === 0 ? '1px solid var(--border-subtle)' : 'none',
                borderBottom: '1px solid var(--border-subtle)',
                alignItems: 'center',
                cursor: 'pointer',
                opacity: isHovered ? 0.5 : 1,
                transition: 'opacity 0.15s',
              }}
              onMouseEnter={() => setHighlight(quote.id)}
              onMouseLeave={() => setHighlight(null)}
              onClick={() => navigate('quote', { id: quote.id })}
            >
              <span
                style={{
                  fontFamily: 'Lora, serif',
                  fontSize: '1rem',
                  color: 'var(--text-tertiary)',
                  fontWeight: 400,
                }}
              >
                {String(i + 4).padStart(2, '0')}
              </span>
              <div style={{ overflow: 'hidden' }}>
                <p
                  style={{
                    fontFamily: 'Lora, serif',
                    fontStyle: 'italic',
                    fontSize: '0.9375rem',
                    lineHeight: 1.55,
                    color: 'var(--text)',
                    marginBottom: '3px',
                    overflow: 'hidden',
                    display: '-webkit-box',
                    WebkitLineClamp: 2,
                    WebkitBoxOrient: 'vertical',
                  }}
                >
                  "{quote.content}"
                </p>
                <p style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>
                  — {author?.name}
                </p>
              </div>
              <div
                style={{ display: 'flex', alignItems: 'center', gap: '0.875rem', flexShrink: 0 }}
                onClick={(e) => e.stopPropagation()}
              >
                <span style={{ fontSize: '0.75rem', color: 'var(--text-tertiary)' }}>
                  {entry.count.toLocaleString()}
                </span>
                <button
                  onClick={() => {
                    toggleFavorite(quote.id)
                  }}
                  style={{
                    background: 'none',
                    border: 'none',
                    padding: 0,
                    fontSize: '0.875rem',
                    color: isFav ? 'var(--text)' : 'var(--text-tertiary)',
                    transition: 'color 0.15s',
                  }}
                >
                  {isFav ? '♥' : '♡'}
                </button>
                <button
                  onClick={() => copy(quote.id, quote.content, author?.name ?? '')}
                  style={{
                    background: 'none',
                    border: 'none',
                    padding: 0,
                    fontSize: '0.75rem',
                    color: copied === quote.id ? 'var(--text)' : 'var(--text-tertiary)',
                    transition: 'color 0.15s',
                  }}
                >
                  {copied === quote.id ? '✓' : '⎘'}
                </button>
              </div>
            </div>
          )
        })}
      </div>
    </main>
  )
}
