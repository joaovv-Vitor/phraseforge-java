import { useState } from 'react'
import { QUOTES, AUTHORS, CATEGORIES, getAuthor } from '../data'

type AdminSection = 'dashboard' | 'phrases' | 'authors' | 'categories' | 'tags' | 'add-phrase'

export default function Admin() {
  const [section, setSection] = useState<AdminSection>('dashboard')
  const [phraseSearch, setPhraseSearch] = useState('')
  const [form, setForm] = useState({
    content: '',
    author: '',
    year: '',
    language: 'English',
    categories: '',
    tags: '',
  })
  const [saved, setSaved] = useState(false)

  const filteredQuotes = QUOTES.filter((q) => {
    const author = getAuthor(q.authorId)
    return (
      phraseSearch === '' ||
      q.content.toLowerCase().includes(phraseSearch.toLowerCase()) ||
      author?.name.toLowerCase().includes(phraseSearch.toLowerCase())
    )
  })

  const navItems: { id: AdminSection; label: string }[] = [
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'phrases', label: 'Phrases' },
    { id: 'authors', label: 'Authors' },
    { id: 'categories', label: 'Categories' },
    { id: 'tags', label: 'Tags' },
  ]

  return (
    <div style={{ display: 'flex', minHeight: 'calc(100vh - 52px)' }}>
      {/* Sidebar */}
      <aside
        style={{
          width: '200px',
          borderRight: '1px solid var(--border-subtle)',
          padding: '2rem 1rem',
          flexShrink: 0,
        }}
      >
        <p
          style={{
            fontSize: '0.6875rem',
            fontWeight: 600,
            letterSpacing: '0.1em',
            textTransform: 'uppercase',
            color: 'var(--text-tertiary)',
            marginBottom: '1rem',
            paddingLeft: '8px',
          }}
        >
          Admin
        </p>
        <nav style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
          {navItems.map(({ id, label }) => (
            <button
              key={id}
              onClick={() => setSection(id)}
              style={{
                background: section === id ? 'var(--border-subtle)' : 'none',
                border: 'none',
                borderRadius: 'var(--radius)',
                padding: '7px 8px',
                fontSize: '0.875rem',
                fontWeight: section === id ? 500 : 400,
                color: section === id ? 'var(--text)' : 'var(--text-secondary)',
                textAlign: 'left',
                transition: 'all 0.15s',
              }}
            >
              {label}
            </button>
          ))}
        </nav>
      </aside>

      {/* Content */}
      <main style={{ flex: 1, padding: '2.5rem', overflow: 'auto' }}>
        {section === 'dashboard' && (
          <div>
            <h2 style={{ fontFamily: 'Lora, serif', fontSize: '1.75rem', fontWeight: 400, color: 'var(--text)', marginBottom: '2rem' }}>
              Dashboard
            </h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))', gap: '1rem', marginBottom: '2.5rem' }}>
              {[
                { label: 'Total Phrases', value: QUOTES.length },
                { label: 'Authors', value: AUTHORS.length },
                { label: 'Categories', value: CATEGORIES.length },
                { label: 'Languages', value: 1 },
              ].map(({ label, value }) => (
                <div
                  key={label}
                  style={{
                    border: '1px solid var(--border)',
                    borderRadius: 'var(--radius)',
                    padding: '1.5rem',
                    background: 'var(--bg-card)',
                  }}
                >
                  <p style={{ fontSize: '0.75rem', color: 'var(--text-tertiary)', marginBottom: '0.5rem' }}>{label}</p>
                  <p style={{ fontFamily: 'Lora, serif', fontSize: '2rem', fontWeight: 400, color: 'var(--text)' }}>{value}</p>
                </div>
              ))}
            </div>
            <div style={{ border: '1px solid var(--border)', borderRadius: 'var(--radius)', overflow: 'hidden' }}>
              <div style={{ padding: '1rem 1.25rem', borderBottom: '1px solid var(--border-subtle)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <p style={{ fontSize: '0.875rem', fontWeight: 500, color: 'var(--text)' }}>Recent Phrases</p>
                <button onClick={() => setSection('phrases')} style={{ background: 'none', border: 'none', fontSize: '0.8125rem', color: 'var(--text-secondary)', transition: 'color 0.15s' }}>
                  View all →
                </button>
              </div>
              {QUOTES.slice(0, 5).map((q, i) => {
                const author = getAuthor(q.authorId)
                return (
                  <div
                    key={q.id}
                    style={{
                      padding: '0.875rem 1.25rem',
                      borderBottom: i < 4 ? '1px solid var(--border-subtle)' : 'none',
                      display: 'flex',
                      justifyContent: 'space-between',
                      gap: '1rem',
                    }}
                  >
                    <p style={{ fontSize: '0.875rem', color: 'var(--text)', flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      "{q.content}"
                    </p>
                    <p style={{ fontSize: '0.8125rem', color: 'var(--text-tertiary)', flexShrink: 0 }}>
                      {author?.name}
                    </p>
                  </div>
                )
              })}
            </div>
          </div>
        )}

        {section === 'phrases' && (
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1.5rem', flexWrap: 'wrap', gap: '1rem' }}>
              <h2 style={{ fontFamily: 'Lora, serif', fontSize: '1.75rem', fontWeight: 400, color: 'var(--text)' }}>
                Phrases
              </h2>
              <button
                onClick={() => setSection('add-phrase')}
                style={{
                  background: 'var(--text)',
                  color: 'var(--bg)',
                  border: 'none',
                  borderRadius: 'var(--radius)',
                  padding: '8px 16px',
                  fontSize: '0.8125rem',
                  fontWeight: 500,
                  transition: 'opacity 0.15s',
                }}
                onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.opacity = '0.8')}
                onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.opacity = '1')}
              >
                + Add Phrase
              </button>
            </div>
            <div style={{ position: 'relative', marginBottom: '1.25rem', maxWidth: '360px' }}>
              <span style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-tertiary)', fontSize: '0.875rem', pointerEvents: 'none' }}>⌕</span>
              <input
                value={phraseSearch}
                onChange={(e) => setPhraseSearch(e.target.value)}
                placeholder="Search phrases..."
                style={{ width: '100%', background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', padding: '8px 12px 8px 32px', fontSize: '0.875rem', color: 'var(--text)', outline: 'none' }}
              />
            </div>
            <div style={{ border: '1px solid var(--border)', borderRadius: 'var(--radius)', overflow: 'hidden' }}>
              <div style={{ padding: '0.625rem 1rem', borderBottom: '1px solid var(--border-subtle)', display: 'grid', gridTemplateColumns: '1fr 160px 120px 80px', gap: '1rem' }}>
                {['Content', 'Author', 'Categories', ''].map((h) => (
                  <span key={h} style={{ fontSize: '0.6875rem', fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--text-tertiary)' }}>{h}</span>
                ))}
              </div>
              {filteredQuotes.map((q, i) => {
                const author = getAuthor(q.authorId)
                return (
                  <div
                    key={q.id}
                    style={{
                      padding: '0.875rem 1rem',
                      borderBottom: i < filteredQuotes.length - 1 ? '1px solid var(--border-subtle)' : 'none',
                      display: 'grid',
                      gridTemplateColumns: '1fr 160px 120px 80px',
                      gap: '1rem',
                      alignItems: 'center',
                      transition: 'background 0.15s',
                    }}
                    onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.background = 'var(--bg-card)')}
                    onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.background = 'transparent')}
                  >
                    <p style={{ fontSize: '0.875rem', color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      "{q.content}"
                    </p>
                    <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)' }}>{author?.name}</p>
                    <p style={{ fontSize: '0.75rem', color: 'var(--text-tertiary)' }}>{q.categories[0]}</p>
                    <div style={{ display: 'flex', gap: '0.5rem' }}>
                      <button style={{ background: 'none', border: 'none', fontSize: '0.75rem', color: 'var(--text-secondary)', padding: 0 }}>Edit</button>
                      <button style={{ background: 'none', border: 'none', fontSize: '0.75rem', color: 'var(--text-tertiary)', padding: 0 }}>Delete</button>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        )}

        {section === 'add-phrase' && (
          <div style={{ maxWidth: '560px' }}>
            <button
              onClick={() => setSection('phrases')}
              style={{ background: 'none', border: 'none', padding: 0, fontSize: '0.8125rem', color: 'var(--text-tertiary)', marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '6px' }}
            >
              ← Phrases
            </button>
            <h2 style={{ fontFamily: 'Lora, serif', fontSize: '1.75rem', fontWeight: 400, color: 'var(--text)', marginBottom: '2rem' }}>
              Add Phrase
            </h2>
            {saved && (
              <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', padding: '12px 16px', marginBottom: '1.5rem', fontSize: '0.875rem', color: 'var(--text-secondary)' }}>
                ✓ Phrase saved successfully.
              </div>
            )}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
              {[
                { key: 'content', label: 'Content', multiline: true },
                { key: 'author', label: 'Author', multiline: false },
                { key: 'year', label: 'Year', multiline: false },
                { key: 'language', label: 'Language', multiline: false },
                { key: 'categories', label: 'Categories', multiline: false },
                { key: 'tags', label: 'Tags', multiline: false },
              ].map(({ key, label, multiline }) => (
                <div key={key}>
                  <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: 500, color: 'var(--text-secondary)', marginBottom: '6px' }}>
                    {label}
                  </label>
                  {multiline ? (
                    <textarea
                      value={form[key as keyof typeof form]}
                      onChange={(e) => setForm({ ...form, [key]: e.target.value })}
                      rows={4}
                      style={{ width: '100%', background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', padding: '10px 12px', fontSize: '0.9375rem', color: 'var(--text)', outline: 'none', resize: 'vertical', fontFamily: 'Lora, serif', fontStyle: 'italic', lineHeight: 1.6 }}
                      onFocus={(e) => (e.target.style.borderColor = 'var(--text-secondary)')}
                      onBlur={(e) => (e.target.style.borderColor = 'var(--border)')}
                    />
                  ) : (
                    <input
                      value={form[key as keyof typeof form]}
                      onChange={(e) => setForm({ ...form, [key]: e.target.value })}
                      style={{ width: '100%', background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', padding: '10px 12px', fontSize: '0.875rem', color: 'var(--text)', outline: 'none' }}
                      onFocus={(e) => (e.target.style.borderColor = 'var(--text-secondary)')}
                      onBlur={(e) => (e.target.style.borderColor = 'var(--border)')}
                    />
                  )}
                </div>
              ))}
              <button
                onClick={() => {
                  setSaved(true)
                  setForm({ content: '', author: '', year: '', language: 'English', categories: '', tags: '' })
                  setTimeout(() => setSaved(false), 3000)
                }}
                style={{ background: 'var(--text)', color: 'var(--bg)', border: 'none', borderRadius: 'var(--radius)', padding: '11px 24px', fontSize: '0.875rem', fontWeight: 500, alignSelf: 'flex-start', transition: 'opacity 0.15s' }}
                onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.opacity = '0.8')}
                onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.opacity = '1')}
              >
                Save Phrase
              </button>
            </div>
          </div>
        )}

        {section === 'authors' && (
          <div>
            <h2 style={{ fontFamily: 'Lora, serif', fontSize: '1.75rem', fontWeight: 400, color: 'var(--text)', marginBottom: '2rem' }}>Authors</h2>
            <div style={{ border: '1px solid var(--border)', borderRadius: 'var(--radius)', overflow: 'hidden' }}>
              {AUTHORS.map((author, i) => (
                <div
                  key={author.id}
                  style={{ padding: '1rem 1.25rem', borderBottom: i < AUTHORS.length - 1 ? '1px solid var(--border-subtle)' : 'none', display: 'flex', justifyContent: 'space-between', alignItems: 'center', transition: 'background 0.15s' }}
                  onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.background = 'var(--bg-card)')}
                  onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.background = 'transparent')}
                >
                  <div>
                    <p style={{ fontSize: '0.9375rem', fontWeight: 500, color: 'var(--text)', marginBottom: '2px' }}>{author.name}</p>
                    <p style={{ fontSize: '0.8125rem', color: 'var(--text-tertiary)' }}>{author.description}</p>
                  </div>
                  <div style={{ display: 'flex', gap: '0.5rem' }}>
                    <button style={{ background: 'none', border: 'none', fontSize: '0.75rem', color: 'var(--text-secondary)', padding: 0 }}>Edit</button>
                    <button style={{ background: 'none', border: 'none', fontSize: '0.75rem', color: 'var(--text-tertiary)', padding: 0 }}>Delete</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {section === 'categories' && (
          <div>
            <h2 style={{ fontFamily: 'Lora, serif', fontSize: '1.75rem', fontWeight: 400, color: 'var(--text)', marginBottom: '2rem' }}>Categories</h2>
            <div style={{ border: '1px solid var(--border)', borderRadius: 'var(--radius)', overflow: 'hidden' }}>
              {CATEGORIES.map((cat, i) => (
                <div
                  key={cat}
                  style={{ padding: '0.875rem 1.25rem', borderBottom: i < CATEGORIES.length - 1 ? '1px solid var(--border-subtle)' : 'none', display: 'flex', justifyContent: 'space-between', alignItems: 'center', transition: 'background 0.15s' }}
                  onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.background = 'var(--bg-card)')}
                  onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.background = 'transparent')}
                >
                  <p style={{ fontSize: '0.9375rem', color: 'var(--text)' }}>{cat}</p>
                  <div style={{ display: 'flex', gap: '0.5rem' }}>
                    <button style={{ background: 'none', border: 'none', fontSize: '0.75rem', color: 'var(--text-secondary)', padding: 0 }}>Edit</button>
                    <button style={{ background: 'none', border: 'none', fontSize: '0.75rem', color: 'var(--text-tertiary)', padding: 0 }}>Delete</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {section === 'tags' && (
          <div>
            <h2 style={{ fontFamily: 'Lora, serif', fontSize: '1.75rem', fontWeight: 400, color: 'var(--text)', marginBottom: '2rem' }}>Tags</h2>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
              {['mind', 'strength', 'control', 'adversity', 'action', 'resilience', 'virtue', 'character', 'attitude', 'acceptance', 'wisdom', 'self-knowledge', 'introspection', 'music', 'life', 'culture', 'identity', 'society', 'peace', 'engagement', 'freedom', 'inner strength', 'fear', 'presence', 'time', 'soul', 'healing', 'innocence', 'courage', 'truth', 'change'].map((tag) => (
                <span key={tag} style={{ border: '1px solid var(--border)', borderRadius: '99px', padding: '5px 14px', fontSize: '0.8125rem', color: 'var(--text-secondary)' }}>{tag}</span>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  )
}
